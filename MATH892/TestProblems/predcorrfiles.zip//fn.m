function f = fn(x,a)
f = x*x+a*a-1;
return
