function J = fxn(x,a)
J = 2*x;
return
