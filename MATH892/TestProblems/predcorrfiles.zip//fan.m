function fa = fan(x,a)
fa = 2*a;
return
